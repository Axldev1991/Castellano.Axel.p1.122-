package Interface;

public interface CSVSerializable {

    String toCSV();
}
