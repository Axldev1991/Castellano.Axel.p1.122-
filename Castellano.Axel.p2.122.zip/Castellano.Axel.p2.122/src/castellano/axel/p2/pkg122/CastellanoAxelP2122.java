package castellano.axel.p2.pkg122;

import config.RutasArchivos;
import java.io.IOException;
import model.Hechizo;
import model.LibroDeHechizos;
import model.TipoHechizo;

public class CastellanoAxelP2122 {

    public static void main(String[] args) {
        try {
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();
            libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick", TipoHechizo.DEFENSA));
            libro.agregar(new Hechizo(2, "Alohomora", "Desconocido", TipoHechizo.UTILIDAD));
            libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape", TipoHechizo.OSCURO));
            libro.agregar(new Hechizo(4, "Lumos", "Desconocido", TipoHechizo.ENCANTAMIENTO));
            libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape", TipoHechizo.CURACION));

            // Mostrar todos los hechizos
            System.out.println("Hechizos:");
            libro.paraCadaElemento(h -> System.out.println(h));

            // Filtrar por tipo DEFENSA
            System.out.println("\nHechizos de tipo DEFENSA:");
            libro.filtrar(h -> h.getTipo() == TipoHechizo.DEFENSA).forEach(System.out::println);

            // Filtrar por nombre que contenga "lumos"
            System.out.println("\nHechizos que contienen 'lumos':");
            libro.filtrar(h -> h.getNombre().toLowerCase().contains("lumos")).forEach(System.out::println);

            // Ordenar hechizos por ID (orden natural)
            System.out.println("\nHechizos ordenados por ID:");
            libro.ordenar(null);
            libro.paraCadaElemento(h -> System.out.println(h));

            // Ordenar hechizos por nombre
            System.out.println("\nHechizos ordenados por nombre:");
            libro.ordenar((h1, h2) -> h1.getNombre().compareTo(h2.getNombre()));
//            libro.paraCadaElemento(h -> System.out.println(h));

            // Guardar en archivo binario
            libro.guardarEnArchivo(RutasArchivos.getPathBinString());

            // Cargar desde archivo binario
            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
            libroCargado.cargarDesdeArchivo(RutasArchivos.getPathBinString());
            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

            // Guardar en archivo CSV
            libro.guardarEnCSV(RutasArchivos.getPathCSVString());

            // Cargar desde archivo CSV
            libroCargado.cargarDesdeCSV(RutasArchivos.getPathCSVString());
            System.out.println("\nHechizos cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

}
