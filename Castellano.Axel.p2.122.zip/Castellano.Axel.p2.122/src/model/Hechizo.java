package model;

import Interface.CSVSerializable;
import java.io.Serializable;

public class Hechizo implements Comparable<Hechizo>, CSVSerializable, Serializable {

    private int id;
    private String nombre;
    private String creador;
    private TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Hechizo{");
        sb.append("id=").append(id);
        sb.append(", nombre=").append(nombre);
        sb.append(", creador=").append(creador);
        sb.append(", tipo=").append(tipo);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(Hechizo h) {
        return Integer.compare(this.id, h.getId());
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo;
    }

    public static Hechizo fromCSV(String linea) {
        Hechizo toReturn = null;
        String[] partes = linea.split(",");

        if (partes.length == 4) {
            int idCSV = Integer.parseInt(partes[0]);
            String nombreCSV = partes[1];
            String creadorCSV = partes[2];
            TipoHechizo tipoCSV = TipoHechizo.valueOf(partes[3]);
            toReturn = new Hechizo(idCSV, nombreCSV, creadorCSV, tipoCSV);
        }

        return toReturn;

    }

    public static String toCSVHeader() {
        return "id,nombre,creador,tipo\n";
    }

}
