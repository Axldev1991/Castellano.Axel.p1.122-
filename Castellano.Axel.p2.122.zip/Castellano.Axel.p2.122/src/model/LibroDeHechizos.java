package model;

import Interface.CSVSerializable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class LibroDeHechizos<T extends CSVSerializable> {

    private List<T> listaHechizos = new ArrayList();

    public void agregar(T item) {
        listaHechizos.add(Objects.requireNonNull(item));
    }

    public void eliminar(int indice) {
        if (validarIndice(indice)) {
            listaHechizos.remove(indice);
        }
    }

    public T obtenerElemento(int indice) {
        if (validarIndice(indice)) {
            return listaHechizos.get(indice);
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    private boolean validarIndice(int indice) {
        boolean toReturn = true;
        if (indice > listaHechizos.size() || indice < 0) {
            toReturn = false;
        }
        return toReturn;
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaNueva = new ArrayList<>();

        for (T t : listaHechizos) {
            if (criterio.test(t)) {
                listaNueva.add(t);
            }
        }
        return listaNueva;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T hechizo : listaHechizos) {
            accion.accept(hechizo);
        }
    }

    public void ordenar(Comparator<? super T> criterio) {
        listaHechizos.sort(criterio);
    }

    public void guardarEnCSV(String path) throws IOException {
        persistence.PersistenciaHechizos.guardarHechizosCSV((List<? extends Hechizo>) listaHechizos, path);
    }

    public List<Hechizo> cargarDesdeCSV(String path) throws IOException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.cargarHechizosCSV(path);
        return (List<Hechizo>) listaHechizos;
    }

    public void guardarEnArchivo(String path) throws IOException {
        persistence.PersistenciaHechizos.serializarHechizos((List<? extends Hechizo>) listaHechizos, path);
    }

    public List<Hechizo> cargarDesdeArchivo(String path) throws ClassNotFoundException, IOException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.deserializarHechizos(path);
        return (List<Hechizo>) listaHechizos;
    }

}
